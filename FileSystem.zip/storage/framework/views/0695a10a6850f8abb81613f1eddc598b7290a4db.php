<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <a href="/files" class="btn btn-default">Go Back</a>
            <hr>
            <h1>Upload Files</h1>

        </div>
        <div class="row">
            <form action="/files" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="isPublic">Create public Directory?</label>
                    <input type="checkbox" name="isPublic">
                </div>
                <div class="form-group directory-password hide">
                    <label for="password">Create public password?</label>
                    <input type="password" class="form-control">
                </div>
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" class="form-control", placeholder="Title">
                </div>
                <div class="form-group">
                    <input type="file" name="files_path[]" multiple="true">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<script>
    window.onload = () => {
        let checkbox = document.querySelector('input[name="isPublic"]');
        let hideItems = document.querySelector('.directory-password');
        checkbox.addEventListener('click', () => {
                hideItems.classList.toggle('hide');
        })
        console.log(checkbox);
    }

</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\apache2\htdocs\FileSystem\resources\views/files/create.blade.php ENDPATH**/ ?>