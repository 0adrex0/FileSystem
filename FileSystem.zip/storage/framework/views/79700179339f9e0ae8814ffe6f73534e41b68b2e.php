<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <a href="/files" class="btn btn-default">Go Back</a>
                <div class="pull-right">
                        <?php echo e($files->links()); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <form action="/search"  method="GET" class="d-inline-block">
                <?php echo csrf_field(); ?>
                <input type="text" name="search">
                <button type="submit" class="btn" >Search</button>
                <input type="hidden" name="userId" value="<?php echo e($userId); ?>">
            </form>
        </div>
        <div class="row">
            <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">File Name</th>
                    <th scope="col">Extension</th>
                    <th scope="col">Size</th>
                    <th scope="col">Last Modified</th>
                    <th scope="col">Uploaded File</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="col"><?php echo e($key+1); ?></td>
                            <td scope="col"><?php echo e($file->title); ?></td>
                            <td scope="col"><?php echo e($file->extension); ?></td>
                            <td scope="col"><?php echo e($file->size); ?> KB</td>
                            <td scope="col"><?php echo e($file->updated_at); ?></td>
                            <td scope="col"><?php echo e($file->created_at); ?></td>
                            <td scope="col">
                                <div class="d-flex justify-content-around align-items-center text-center">
                                    <?php if(!Auth::guest()): ?>
                                        
                                            <a href="/files/<?php echo e($file->id); ?>/edit" class="btn btn-outline-dark"><i class="fas fa-edit"></i></a>
                                            <a href="/download/<?php echo e($file->id); ?>" class="btn btn-primary"><i class="fas fa-file-download"></i></a>
                                            <form action="/files/<?php echo e($file->id); ?>"  method="POST" class="d-inline-block">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="_method" value="DELETE">
                                                <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
                                            </form>
                                        
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            <hr>


        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\apache2\htdocs\FileSystem\resources\views/files/show.blade.php ENDPATH**/ ?>