<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <nav class="d-flex justify-content-between align-items-baseline">
                    <h1>File System</h1>
                    <a class="btn btn-success" href="/files/create"><div class="glyphicon glyphicon-plus"></div> Add File</a>
                </nav>
                <hr>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <section class="files">
                    <?php if(count($files) > 0): ?>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-file mt-3">
                                    <a class="open_dir" href="/files/<?php echo e($user->id); ?>" data-user_id="<?php echo e($user->id); ?>"><h3><?php echo e($user->email); ?></h3></a>
                                    <small>Created at <?php echo e($user->created_at); ?> </small>
                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p>Files not found</p>
                    <?php endif; ?>
                </section>
            </div>
        </div>
    </div>
    <div class="modal" tabindex="-1" role="dialog" data-toggle="modal" data-target="#myModal">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="/files/" method="GET">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">Директория запаролена</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group ">
                                <label for="password">Введите пароль</label>
                                <input type="password" name="password" class="form-control">
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Enter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>



<script>
    window.onload = function() {
        const $open_dir = document.querySelectorAll(".open_dir");
        const $myModal = document.querySelector('[data-target="#myModal"]');
        for (const key in $open_dir) {
            if ($open_dir.hasOwnProperty(key)) {
                const element = $open_dir[key];
                element.addEventListener('click', () => {
                    event.preventDefault();
                    if(<?php echo e(Auth::user()->id); ?> == element.dataset.user_id)
                        window.location.href = "files/"+ element.dataset.user_id;
                    else{
                        $myModal.classList.toggle('modal');
                        $myModal.querySelector('form').action += element.dataset.user_id;
                    }
                })

            }
        }
    }

</script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bitnami\apache2\htdocs\FileSystem\resources\views/files/index.blade.php ENDPATH**/ ?>